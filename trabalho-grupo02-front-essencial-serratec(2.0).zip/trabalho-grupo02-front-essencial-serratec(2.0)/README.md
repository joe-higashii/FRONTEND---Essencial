# trabalho-grupo02-front-essencial-serratec
Trabalho SerraTec Front Essencial - Pagina de login e de cadastro salvando as informações no LocalStorage + pagina  home consumindo uma api de previsção do tempo 
