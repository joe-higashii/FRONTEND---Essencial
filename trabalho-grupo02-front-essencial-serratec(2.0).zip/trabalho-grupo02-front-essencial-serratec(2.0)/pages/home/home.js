// Definindo a chave da API
const apiKey = "827b9f42a35b0af9fa85bd2da064b005";

// Definindo a URL base para a imagem da bandeira do país
const apiCountryURL = "https://upload.wikimedia.org/wikipedia/commons/thumb/";

// Definindo a URL base para imagens relacionadas ao clima (provavelmente usado para mostrar um ícone de clima)
const apiUnsplash = "https://source.unsplash.com/1600x900/?";

// Selecionando elementos HTML por seus IDs
const cityInput = document.querySelector("#city-input"); // Obtém o elemento de entrada de cidade
const searchBtn = document.querySelector("#search"); // Obtém o botão de pesquisa

// Selecionando elementos HTML por seus IDs para exibir os dados do clima
const cityElement = document.querySelector("#city"); // Obtém o elemento que exibirá o nome da cidade
const tempElement = document.querySelector("#temperature span"); // Obtém o elemento que exibirá a temperatura
const descElement = document.querySelector("#description"); // Obtém o elemento que exibirá a descrição do clima
const weatherIconElement = document.querySelector("#weather-icon"); // Obtém o elemento que exibirá o ícone do clima
const countryElement = document.querySelector("#country"); // Obtém o elemento que exibirá o nome do país
const umidityElement = document.querySelector("#umidity span"); // Obtém o elemento que exibirá a umidade
const windElement = document.querySelector("#wind span"); // Obtém o elemento que exibirá a velocidade do vento

// Obtém o elemento que conterá os dados do clima
const weatherContainer = document.querySelector("#weather-data");

// Obtém o elemento para exibir mensagens de erro
const errorMessageContainer = document.querySelector("#error-message");

// Obtém o elemento para exibir um indicador de carregamento
const loader = document.querySelector("#loader");

// Obtém o contêiner para exibir sugestões de cidades
const suggestionContainer = document.querySelector("#suggestions");

// Obtém todos os botões de sugestão de cidades
const suggestionButtons = document.querySelectorAll("#suggestions button");


// Esta função toggleLoader é usada para alternar a visibilidade de um elemento com a classe "loader".
const toggleLoader = () => {
    loader.classList.toggle("hide");
  };
  
  // Esta função getWeatherData é uma função assíncrona que recebe um parâmetro 'city'.
  const getWeatherData = async (city) => {
    // Chama a função toggleLoader para mostrar ou ocultar o elemento de carregamento (loader).
    toggleLoader();
  
    // Cria a URL da API de previsão do tempo usando a cidade fornecida, unidades métricas, sua chave de API e o idioma português brasileiro.
    const apiWeatherURL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}&lang=pt_br`;
  
    // Faz uma solicitação assíncrona para a URL da API usando a função fetch e armazena a resposta em 'res'.
    const res = await fetch(apiWeatherURL);
  
    // Converte a resposta em formato JSON e armazena os dados em 'data'.
    const data = await res.json();
  
    // Chama novamente a função toggleLoader para ocultar o elemento de carregamento (loader) após a conclusão da solicitação da API.
    toggleLoader();
  
    // Retorna os dados obtidos da API de previsão do tempo.
    return data;
  };
  

// Função para mostrar uma mensagem de erro
const showErrorMessage = () => {
    errorMessageContainer.classList.remove("hide");
  };
  
  // Função para esconder todas as informações (erro, dados climáticos, sugestões)
  const hideInformation = () => {
    errorMessageContainer.classList.add("hide"); // Esconde a mensagem de erro
    weatherContainer.classList.add("hide"); // Esconde o contêiner de dados climáticos
    suggestionContainer.classList.add("hide"); // Esconde o contêiner de sugestões
  };
  
  // Função para mostrar os dados climáticos
  const showWeatherData = async (city) => {
    hideInformation(); // Chama a função para esconder as informações existentes
  
    const data = await getWeatherData(city); // Chama uma função para obter dados climáticos da API
  
    // Verifica se a resposta da API possui o código de erro "404" (cidade não encontrada)
    if (data.cod === "404") {
      showErrorMessage(); // Se sim, mostra a mensagem de erro e retorna
      return;
    }
  
    // Preenche os elementos HTML com os dados obtidos da API
    cityElement.innerText = data.name; // Nome da cidade
    tempElement.innerText = parseInt(data.main.temp); // Temperatura
    descElement.innerText = data.weather[0].description; // Descrição do clima
    weatherIconElement.setAttribute(
      "src",
      `http://openweathermap.org/img/wn/${data.weather[0].icon}.png`
    ); // Define o ícone do clima
    countryElement.setAttribute(
      "src",
      apiCountryURL + data.sys.country + "/flag.png"
    ); // Define a bandeira do país
    umidityElement.innerText = `${data.main.humidity}%`; // Umidade
    windElement.innerText = `${data.wind.speed}km/h`; // Velocidade do vento
  
    // Altera a imagem de fundo do corpo da página com base na cidade
    document.body.style.backgroundImage = `url("${apiUnsplash + city}")`;
  
    weatherContainer.classList.remove("hide"); // Mostra o contêiner de dados climáticos
  };
  

// Adiciona um evento de clique no elemento com o ID "searchBtn"
searchBtn.addEventListener("click", async (e) => {
    e.preventDefault(); // Evita o comportamento padrão de um clique em um botão, que é recarregar a página
  
    const city = cityInput.value; // Obtém o valor inserido no elemento com o ID "cityInput"
  
    showWeatherData(city); // Chama a função showWeatherData com o nome da cidade como argumento
  });
  
  // Adiciona um evento de tecla pressionada no elemento com o ID "cityInput"
  cityInput.addEventListener("keyup", (e) => {
    if (e.code === "Enter") { // Verifica se a tecla pressionada foi a tecla "Enter"
      const city = e.target.value; // Obtém o valor inserido no elemento com o ID "cityInput"
  
      showWeatherData(city); // Chama a função showWeatherData com o nome da cidade como argumento
    }
  });
  
  // Itera sobre os elementos com a classe "suggestionButtons"
  suggestionButtons.forEach((btn) => {
    // Adiciona um evento de clique a cada botão de sugestão
    btn.addEventListener("click", () => {
      const city = btn.getAttribute("id"); // Obtém o ID do botão clicado
  
      showWeatherData(city); // Chama a função showWeatherData com o nome da cidade (ID do botão) como argumento
    });
  });
  